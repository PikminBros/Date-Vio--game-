﻿# Declare characters
define e = Character("Vio", color="#cca625")
define s = Character("Stikman", color="#ffffff") # For Stikman dialogue
define sh = Character("Shiver", color="#a7c6e7") # For Shiver dialogue
define h = Character("Hira", color="#a8ffc4") # Mint green for Hira
define g = Character("Gabby", color="#9e9e9e") # Gray for Gabby
define a = Character("Alby", color="#ffa500") # Orange for Alby
define n = Character(None, color="#ffffff") # For unassigned narrator text
define hb = Character("Hira's Boss", color="#ffffff") # For unassigned narrator text
define p = Character("Performer Flareon", color="#ffa500") # For unassigned narrator text

# Solid background definitions
image bg black = "#000000"
image bg white = "#ffffff"

# Position and scale for 1080p canvas
transform vio_scale:
    zoom 0.58
    xalign 0.5
    yalign 1.0

# Position for left side of the screen
transform vio_left:
    zoom 0.58
    xalign 0.2
    yalign 1.0

# Extreme left position so Vio is near the border and Gabby is fully visible
transform vio_extreme_left:
    zoom 0.58
    xalign -0.2
    yalign 1.0

# Extreme border positions for Alby and Shiver so they frame Vio nicely
transform alby_extreme_left:
    zoom 0.58
    xalign 0.05
    yalign 1.0

transform shiver_extreme_right:
    zoom 0.58
    xalign 0.95
    yalign 1.0

transform hira_extreme_right:
    zoom 0.58
    xalign 0.95
    yalign 1.0

# Positions for the outdoor Stikman encounter
transform stikman_left:
    zoom 0.58
    xalign 0.2
    yalign 1.0

transform vio_right:
    zoom 0.58
    xalign 0.8
    yalign 1.0

# Default persistent variables (remembered across restarts)
default persistent.player_name = "Player"
default persistent.got_true_ending = False
default player_name = "Player"

label start:

    # Load remembered name if it exists
    $ player_name = persistent.player_name

    # If player completed True Ending, hitting Start skips to Scene Four!
    if persistent.got_true_ending:
        jump scene_four_molten_lava

    # 1. Opening Warning / Disclaimer
    scene bg makename:
        xysize (1920, 1080)
    with dissolve

    "hi, welcome to Date Vio."
    "Before you say something dumb dumb dumb"
    "la la la la la lala"
    "sorry"
    "just know this game is SATIRE, and a JOKE. and is NOT canon."
    "okay, what's-your-name, enter ya name."
    "the narrator dies"

    # Name Input Prompt
    python:
        name_input = renpy.input("you know what to do, bud.", default="Player")
        name_input = name_input.strip()
        if not name_input:
            name_input = "Player"
        player_name = name_input
        persistent.player_name = name_input

    # 2. Scene One Intro - The Search for Employment
    scene bg black
    with dissolve

    n "You [player_name], have been looking for your place of employment all day, but couldn't find it."
    n "Then you see it."

    scene bg outsidegym:
        xysize (1920, 1080)
    with dissolve

    n "You think \"wait... is that my workplace?\"..."

    scene bg gym:
        xysize (1920, 1080)
    with dissolve

    n "You walk in, you look around. Yep. This was it."
    n "Your role was just to watch the gymgoers, to make sure they don't kill themselves or something."
    n "You see your assigned bench and walk over to it, then you sit on it."
    n "Then someone, a pokemon looks at you, then walks over to you. The first thing you notice is that this person isn't wearing clothes, but you look around, notice that this is a POKEMON GYM. Anthro Pokemon don't wear clothes. Well, some do, but Anthro Pokemon don't have reproductive organs, so you settle a bit."

    # 3. Vio Appears
    show vio netural at vio_scale
    with dissolve

    e "...Oh. Hey...?- Oh wait! You must be that new guy here..."

    "Vio thinks"

    show vio bored at vio_scale
    e "hmm...uhhh...."

    show vio shocked at vio_scale
    e ""

    show vio worried at vio_scale
    e "Your name was....uh... [player_name], right?"

    menu:
        "Yes":
            pass

        "No":
            scene bg youlied:
                xysize (1920, 1080)
            with dissolve
            n ""
            return

    # Continuing if player chose "Yes":
    show vio worriedright at vio_scale
    e "Okay! - I-i didn't think you were gonna be so...."

    show vio ehh at vio_scale
    e "DIRECT about that..."

    show vio confused at vio_scale
    e "I'm usually pretty shy when I tell people I don't know my name..."

    show vio happy at vio_scale
    e "But...if you're feeling confident...."

    e "...My name's Vio."

    show vio veryhappy at vio_scale
    e "Yours is [player_name], but I already knew that."


    # --- SCENE TWO ---

    show vio smug at vio_scale
    with dissolve

    e "Watch me lift this dumbbell."

    n "Vio attempts to lift the dumbbell, which is a rock. A really BIG one. It slips out of her hand and falls onto her."

    show vio scaredleft at vio_scale
    e "GAH!!!"

    show vio scaredtwyou at vio_scale
    e "......I-i think my legs are broken....?"

    e "C-could you push this off of me....?"

    show vio sad at vio_scale
    e "......Please...?"

    menu:
        "Push rock off of her":
            pass

        "Use your camera to take a picture to blackmail her":
            jump vio_pissed_ending

        "Stare":
            jump vio_pissed_ending


    # If player chose to push the rock:
    n "You, [player_name] push the rock off of her, somehow."

    show vio suprisedwithelect at vio_scale
    e "H-how did you DO that?!"

    # Dialogue options hub (one-time choice)
    menu:
        "Never mind that. Can you stand?":
            show vio worried at vio_scale
            e "...U-uh...let's see...."

        "Are you hurt or bleeding anywhere??":
            show vio scareddown at vio_scale
            e "...Nope."
            
            show vio scaredtwyou at vio_scale
            e "Let's see If I can stand..."
            
            show vio worried at vio_scale
            e "...U-uh...let's see...."

    n "Vio attempts to stand"
    
    show vio scaredleft at vio_scale
    e "Catchmecatchmecatchmecatchme"
    
    menu:
        "Catch Vio":
            jump vio_caught

        "Don't catch Vio":
            jump vio_pissed_ending


# Catch route continuation
label vio_caught:
    show vio sad at vio_scale
    e "I think I can walk... I might have to be trained to walk again though... It's really numb."
    
    show vio tired at vio_scale
    e "...Umm...-"

    n "Vio's phone dings"
    n "Vio checks her phone."

    show vio worried at vio_scale
    e ""

    n "her phone dings again"

    show vio shocked at vio_scale
    e ""

    show vio scaredtwyou at vio_scale
    e "...[player_name].........."

    e ".......my house......."

    n "vio snifs sadly"

    show vio sad at vio_scale
    e "....It's gone...."

    e "...I-i don't know what to do...."

    e "...Could you let me stay at your place?"

    menu:
        "Yeah. It's alright. It's late too, better late than never.":
            pass

        "...It's uh.... too messy?":
            jump vio_left_her_ending

    show vio tiredhappy at vio_scale
    e "...T-thank you..."

    show vio extremelyhappy at vio_scale
    e ""

    scene bg playerhousenight:
        xysize (1920, 1080)
    with dissolve

    show vio tired at vio_left
    with dissolve

    e "Is...that your house?"

    show vio tiredhappy at vio_left
    e "Looks nice....."

    show vio sleeping at vio_left
    e "zzz....! HUH?"

    show vio shocked at vio_left
    e ""

    show vio tired at vio_left
    e "...S-sorry........I-i'm so tired..."

    e "....Could you carry me inside.......? ...I'm really tired."

    menu:
        "Yes":
            pass

    scene bg insidehouse:
        xysize (1920, 1080)
    with dissolve

    show vio tired at vio_scale
    with dissolve

    e "...I-it's wonderful..."

    show vio tiredhappy at vio_scale
    e "...hehehe......"

    n "Vio collapses due to overexaustion"

    show vio sleepinghappy at vio_scale
    e ""

    $ couch_button_text = "Put her on the couch"

    label carry_choice_loop:
        menu:
            "Carry Vio to bedroom":
                pass

            "[couch_button_text]":
                $ couch_button_text = "She's cold. The bed's better."
                jump carry_choice_loop

    scene bg insidehousethree:
        xysize (1920, 1080)
    with dissolve

    n "You carefully tuck her into your bed. Then you get in next to her. Being sure not to wake her, not that you would."

    scene bg playerhousenight:
        xysize (1920, 1080)
    with dissolve

    $ renpy.pause(3.0, hard=True)

    scene bg playerhouse:
        xysize (1920, 1080)
    with dissolve


    # --- SCENE THREE ---

    scene bg insidehousefour:
        xysize (1920, 1080)
    with dissolve

    show vio sleepinghappy at vio_scale
    e ""

    show vio smug at vio_scale
    $ renpy.pause(0.15)
    show vio happy at vio_scale
    e ""

    e "...Morning."

    n "You're awake"

    show vio happy at vio_scale
    e "T-thank you for...last night..."

    e "Could I hug you?"

    menu:
        "Yes":
            show vio veryhappy at vio_scale
            e "R-REALLY?"

            show vio extremelyhappy at vio_scale
            e "T-thank you!"

            n "Vio hugs you, tight."
            n "This is when you realize she kinda smells like cinnamon."

            menu:
                "Why do you smell like cinnamon?":
                    pass

            show vio happy at vio_scale
            e "...It's natural!!"

            show vio ehh at vio_scale
            e "Why...don't we go out somewhere?"

        "No":
            show vio sad at vio_scale
            e "A-alright..."

            n "Vio leans against you."
            n "This is when you realize she kinda smells like cinnamon."

            menu:
                "Why do you smell like cinnamon?":
                    pass

            show vio disappointed at vio_scale
            e "...It's natural...!"

            show vio disappointedtwo at vio_scale
            e "Why don't we go out somewhere......?"

            menu:
                "Yeah, we should.":
                    pass

                "I'm tired":
                    pass

    show vio happy at vio_scale
    e "...Yeah...."

    n "You, [player_name] and Vio both walk outside."

    scene bg grass:
        xysize (1920, 1080)
    with dissolve

    show stikman happy at stikman_left
    show vio extremelyhappy at vio_right
    with dissolve

    s "...HEY KID."
    s "COME HERE~"

    n "Vio steps closer."

    show stikman reallyhappy at stikman_left
    s "YIPPEEE"

    show stikman pulloutknife at stikman_left
    s ""

    show stikman holdoutknife at stikman_left
    s ""

    show stikman stab at stikman_left
    s "HEHEHEHEHHEHEHE"

    show vio staretwyouwhilestabbed at vio_right
    e "AAH!!!!!!"

    show stikman joy at stikman_left
    s "HEHEHEHEHEHEHEHEHAHAHAHAHAHAHAHA"

    show vio looksatstabwound at vio_right
    e "....OWWW.....FUCK."

    menu:
        "PUNCH STIKMAN IN FACE":
            pass

        "ECAF NI NAMKITS HCNUP":
            pass

    show stikman tired at stikman_left
    s "HOLY COW!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

    show stikman shout at stikman_left
    s "WHY"
    s "YOU"
    s "LITTLE"
    s "PEICE"
    s "OF"
    s "SHIT."

    show stikman thumbsup at stikman_left
    s "THAT WAS JUST AMAZINGGGG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

    show stikman hehe at stikman_left
    s "NOW, [player_name]. GO ███ YOURSELF."

    show stikman illalwaysbehere at stikman_left
    s "LOOK KID, I'LL ALWAYS BE HERE. HEHEHHEAHHEHE..."

    show stikman angry at stikman_left
    s "AND LOOK, [player_name]. YOU SHOULD GO ████████████████."

    show stikman byebye at stikman_left
    s "BYE BYEE"

    show stikman byby at stikman_left
    s ""

    show stikman bb at stikman_left
    s ""

    show stikman yy at stikman_left
    s ""

    hide stikman with Pixellate(0.3, 5)

    n "Stikman ████es out of reality."

    n "Vio grabs your leg."

    show vio dizzy at vio_scale
    e "...Call someone....anyone..."

    n "You pull out your phone, and call emergency services."

    scene bg black:
        xysize (1920, 1080)
    with dissolve

    n "Eventually, the ambulance came. You were able to stop her wound from bleeding out too much, Vio herself is too weak to say anything. She feels stupid."
    n "After getting the discharge papers, you two were allowed to go home, so you did."

    scene bg insidehousetwo:
        xysize (1920, 1080)
    with dissolve

    show vio cryingbandaged at vio_scale
    e ""

    n "You walk over to Vio, and put your hand on her shoulder, patting it softly."

    show vio lookawayfromyoubandaged at vio_scale
    e ""

    menu:
        "Vio, you need rest.":
            pass

        "Vio. Sleep. Now.":
            pass

    show vio cryingbandaged at vio_scale
    e ""

    n "Vio nods, then hugs you, then winces."
    n "She wanted to show you more affection but was too sore to DO anything more."
    n "You hold Vio in your arms as she falls asleep. You then go to your bedroom and tuck her in carefully."

    scene bg insidehousefour:
        xysize (1920, 1080)
    with dissolve

    show vio lookawayfromyoubandaged at vio_scale
    e ""

    n "Vio hugs you really tightly, then kisses you, very lightly on the cheek."
    n "Vio falls asleep."

    jump true_ending


# Bad ending handler for when you leave her
label vio_left_her_ending:
    scene bg youlefther:
        xysize (1920, 1080)
    with dissolve
    n ""
    return


# Bad ending handler for when Vio gets pissed
label vio_pissed_ending:
    scene bg viopissed:
        xysize (1920, 1080)
    with dissolve
    n ""
    return


# True ending handler
label true_ending:
    $ persistent.got_true_ending = True
    scene bg true:
        xysize (1920, 1080)
    with dissolve
    n ""
    return


# ==========================================
# SCENE FOUR -Molten Lava 7700-
# ==========================================
label scene_four_molten_lava:
    scene bg black:
        xysize (1920, 1080)
    with dissolve

    n "Two. Months."
    n "Two Months have passed since Vio was violently attacked by that guy."
    n "Vio had gotten her voice back since then."

    scene bg insidehousefour:
        xysize (1920, 1080)
    with dissolve

    show vio disappointed at vio_scale
    with dissolve
    e "...M-morning....[player_name]...."

    show vio happy at vio_scale
    e "...I.....uh..."

    show vio worriedright at vio_scale
    e "...I-i.....snuck out and bought tickets to....uh..."

    show vio sad at vio_scale
    e "...uhhhh.......it was a concert called.........."

    show vio sad at vio_scale
    e "Molten Lava 7700..."

    show vio disappointedtwo at vio_scale
    e "...Don't be mad...."

    $ second_option_text = "I really hope you used your own money, Vio."

    label concert_money_loop:
        menu:
            "It's fine, Vio.":
                pass

            "[second_option_text]":
                $ second_option_text = "I really hope you used your own money, Vio."
                show vio scareddown at vio_scale
                e "I-I DID!!!"
                e ".....I did!"
                jump concert_money_loop

    show vio tiredhappy at vio_scale
    e "....thanks for....not being mad at me."

    show vio tired at vio_scale
    e "[player_name]...I'll go get ready."

    scene bg club:
        xysize (1920, 1080)
    with dissolve

    show vio bored at vio_right
    with dissolve
    e "There it is."

    show vio netural at vio_right
    e "Let's go in, [player_name]"

    scene bg insideclub:
        xysize (1920, 1080)
    with dissolve

    show hira normal at vio_scale
    with dissolve
    h "Hi. Welcome to \"The Cool, New Club thing across the highway\"."
    h "I'm gonna need your tickets."

    n "Vio gives your and her own tickets to Hira"

    show hira normaltwo at vio_scale
    h "uhh...."

    show hira normal at vio_scale
    h "So you are... [player_name] and Vio Vanaesuses...?"

    n "Vio nods"
    n "Hira points towards a door."
    hide hira with dissolve
    n "Vio drags you along to the door."
    n "Someone gets infront of that door"

    # Vio moved to extreme left so Gabby in the middle is fully visible
    show gabby asset at vio_scale
    show vio eyetwitch2 at vio_extreme_left
    with dissolve
    g "Hey, like... bitches."

    # Door approach dialouge
    menu:
        "Out of our way.":
            pass

        "Could you please move?":
            pass

        "Move. It.":
            pass

    g "As like, IF."

    show vio pissed at vio_extreme_left
    with dissolve
    e "I PAID MORE THAN FOURTY DOLLARS FOR THIS."
    e "OUT OF OUR WAY."

    show gabby asset at vio_scale
    g "As like, IF."

    $ reason_button_text = "Talk this out reasonably"

    label door_guard_loop:
        menu:
            "Let Vio electrocute Gabby to death":
                pass

            "[reason_button_text]":
                $ reason_button_text = "She's just gonna say \"As like, IF.\""
                jump door_guard_loop

    show vio deadpan at vio_extreme_left
    e "hehehehe...."

    show gabby asset at vio_scale
    g "As like, IF."

    n "Vio electrocutes Gabby."
    g "AAAAAAAAAAAHHHH"

    n "Gabby falls to the floor."
    hide gabby with dissolve

    n "Vio kicks Gabby's corpse away, then opens the door, for you."

    show vio tiredhappy at vio_scale
    e "You first."

    n "You walk through, as she said, then find your seats."
    n "Vio follows you to the seat next to you."

    # Vio in the middle, Alby on far left border and Shiver on far right border framing Vio
    show vio tiredhappy at vio_scale
    show alby asset at alby_extreme_left
    show shiver netural at shiver_extreme_right
    with dissolve

    a "It's STARTTTTINGGGG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    sh "Yep. It is."
    sh "...W-wait...."
    show shiver nervleft at shiver_extreme_right
    n "Shiver looks at Vio, then quickly looks away."
    show shiver nervright at shiver_extreme_right    
    a "What's wrong, buddy?"
    show vio confused at vio_scale
    e "...Uhhh......Where's the preformer...?"
    a "....correction: preformERS."
    show shiver shouting at shiver_extreme_right
    sh "DON'T TALK TO HER LIKE THAT."
    a "SHH. This is a CONCERT."
    show shiver angryhappy at shiver_extreme_right
    sh "Never talk to her like that."
    a "Why do you care?"
    show shiver grr at shiver_extreme_right
    sh "Does it matter why?"
    n "ATTENTION ALL CONCERTGOERS: YOU ARE ALL VERY EARLY. YOU CAN CONVERSE WITH ONE ANOTHER OR PLAY GAMES ON YOUR PHONES. THE PREFORMERS WILL BE HERE SOMEWHAT SHORTLY."
    show shiver shocked at shiver_extreme_right
    show vio shocked at vio_scale
    a "words cannot begin to describe how much i hate this very moment on the planet we call home."
    show vio scaredleft at vio_scale
    e "You aren't a philosopher..."
    show alby assett at alby_extreme_left
    e "....What the-"
    show shiver nervleft at shiver_extreme_right
    sh "Chill out. This is a concert. Oh, hey. I'm pretending to be you."
    show alby asset at alby_extreme_left
    show vio ehh at vio_scale
    e "...[player_name], did you see that?"
    show vio worried at vio_scale
    e "...That was spooky....."
    a "...I am so pissed at how slow these performers are....I might just..."
    show shiver happy at shiver_extreme_right
    sh "...You could just what? Update to iOS 27?"
    sh "Do it. You look like you can barely handle Minecraft Bedrock on simple graphics with shadows."
    show alby assett at alby_extreme_left
    a ""
    show shiver nervleft at shiver_extreme_right
    sh "Stop doing that."
    show alby grab at alby_extreme_left
    sh ".....???"
    show alby grab at shiver_extreme_right
    sh "What are...you doing?"
    show alby assettt at shiver_extreme_right
    show shiver nervright at alby_extreme_left
    show vio scaredright at vio_scale
    e "...Why'd you do that?"
    show alby stare at shiver_extreme_right
    n "Alby looks like he's about to leave."
    hide alby
    n "Alby left for better seats."
    show vio ehh at vio_scale
    e "...So, do you like uh...cheesecake?"
    show shiver happy at alby_extreme_left
    sh "...Y-yeah. Yeah. I do."
    show vio scaredleft at vio_scale
    e "...I was talking to [player_name]."
    show shiver nervleft at alby_extreme_left
    sh "O-oh."
    show hira normaltwo at hira_extreme_right
    h "...Hi."
    show hira normal at hira_extreme_right
    show shiver nervright at alby_extreme_left
    show vio bored at vio_scale
    sh "Oh. Hi, Hira."
    hb "HIRA COME BACK HERE NOW."
    show hira normaltwo at hira_extreme_right
    h "Peace."
    hide hira
    n "step step step"
    p "Sorry I was lat-"
    n "crowd cheers"
    p "Just gotta wait for the group."
    n "crowd falls silent"
    p "...I'm joking."
    n "crowd laughs kinda."
    show shiver nervtwyou at alby_extreme_left
    sh "...You barely talk...huh?"
    show vio disappointedtwo at vio_scale
    e "...Don't be rude to [player_name]. Maybe they're...uh.....non-verbal?"
    show shiver shouting at alby_extreme_left
    show vio eyetwitch2 at vio_scale
    sh "Rude? I was just pointing out a FACT!"
    show vio happy at vio_scale
    show shiver happy at alby_extreme_left
    sh "Okay. I shouldn't have shouted. Can we just hug and forget?"
    e "Okay... I guess? But if we're hugging, we're hugging with [player_name]."
    sh "Well, I don't exactly care about that..."
    n "he did"
    sh "Can we just hug already?"
    e "Alright..."
    n "Vio pulls you, and shiver into a hug."
    show shiver flustered at vio_scale
    sh "heheheh...."
    hide shiver
    hide vio
    scene bg cont:
        xysize (1920, 1080)
    with dissolve
    n ""
    return